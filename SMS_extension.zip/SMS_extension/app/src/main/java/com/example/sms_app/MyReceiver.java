package com.example.sms_app;

import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.RequiresApi;

import static com.example.sms_app.DatabaseHelper.COLUMN_CONTENT;
import static com.example.sms_app.DatabaseHelper.COLUMN_NAME;

public class MyReceiver extends BroadcastReceiver {



    @Override
    public void onReceive(Context context, Intent intent) {

        Bundle bundle = intent.getExtras();

        if (bundle != null) {

            Object[] smsExtra = (Object[]) bundle.get("pdus");
            SmsMessage sms = SmsMessage.createFromPdu((byte[]) smsExtra[0]);

            PendingResult pendingResult = goAsync();
            MessageStored messageStored = new MessageStored(context, pendingResult, sms );
            messageStored.execute();

        }

    }



    public static class MessageStored extends AsyncTask<Void,Void,Long>{

        private String URI = "content://com.example.sms_app/users";
        private Context mContext;
        private PendingResult mPendingResult;
        private SmsMessage mSms;
        private String messages;

        public MessageStored(Context context, PendingResult pendingResult, SmsMessage sms ) {
            this.mContext = context;
            this.mPendingResult = pendingResult;
            this.mSms = sms;
        }

        @RequiresApi(api = Build.VERSION_CODES.R)
        @Override
        protected Long doInBackground(Void... voids) {
            String name = mSms.getOriginatingAddress();
            String content = mSms.getMessageBody();

            DatabaseHelper db = DatabaseHelper.getInstance(mContext);
            if (db.checkBlockedContacts(mContext, name)) {
                long id = 0;
                return id;
            } else {


                ContentValues cValues = new ContentValues();
                cValues.put(COLUMN_NAME, name);
                cValues.put(COLUMN_CONTENT, content);
                Uri uri=mContext.getContentResolver().insert(Uri.parse(URI),cValues);

                messages = "SMS from " + name + ":\n" + content + "\n";
                Long id = Long.valueOf(uri.getLastPathSegment());
                return id;


            }

        }

        @Override
        protected void onPostExecute(Long aLong) {
            super.onPostExecute(aLong);
            if (aLong==0) {
                Toast.makeText(mContext,"Message Blocked ", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(mContext,"Row Number: "+ String.valueOf(aLong), Toast.LENGTH_SHORT).show();
                Toast.makeText(mContext, messages, Toast.LENGTH_SHORT).show();
            }

            mPendingResult.finish();



        }
    }
}


