package com.example.sms_app;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_DENIED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECEIVE_SMS}, 1000);
        }

        String s=getSharedPreferences();
        if (s.equals("0.0")){
            writeTextFile("0.0");
            storeSharedPreferences("1.0");
        }


        ArrayList<String> blockedContactsList = new ArrayList<String>() {
            {
                add("6505551212");
                add("6505551213");
                add("6505551214");
                add("6505551215");
                add("6505551216");
            }
        };

        writeCsvFile(blockedContactsList);

        String s1 = getSharedPreferences();
        String s2 = readTextFile();

        if (!s1.trim().equalsIgnoreCase(s2.trim())) {
            ArrayList<String> csv = readCsvFile();
            DatabaseHelper db = DatabaseHelper.getInstance(this);
            for (int i = 0; i < csv.size(); i++) {
               Long id = db.insertBlockContact(this, csv.get(i));
            }
            writeTextFile("1.0");
        }

    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {


        } else if (shouldShowRequestPermissionRationale(Manifest.permission.RECEIVE_SMS)) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECEIVE_SMS}, 1000);

        }
    }

    private void storeSharedPreferences(String version) {
        SharedPreferences sharedPreferences = getSharedPreferences("version", Context.MODE_PRIVATE);
        SharedPreferences.Editor sharedPreferencesEditor = sharedPreferences.edit();
        sharedPreferencesEditor.putString("version_key", version);
        sharedPreferencesEditor.apply();

    }

    private String getSharedPreferences() {
        SharedPreferences sharedPreferences = getSharedPreferences("version", Context.MODE_PRIVATE);
        return sharedPreferences.getString("version_key", "0.0");
    }


    public void writeTextFile(String version) {
        try {
            FileOutputStream fos = openFileOutput("textFile.txt", MODE_PRIVATE);
            fos.write(version.getBytes());

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void writeCsvFile(ArrayList<String> blockedNumber) {

        try {
            FileOutputStream fos = openFileOutput("csvFile.csv", MODE_PRIVATE);
            for (int i = 0; i < blockedNumber.size(); i++) {
                fos.write(blockedNumber.get(i).getBytes());
                fos.write("\n".getBytes());
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String readTextFile() {

        try {
            FileInputStream fis = openFileInput("textFile.txt");
            InputStreamReader isr = new InputStreamReader(fis, StandardCharsets.UTF_8);

            BufferedReader bufferedReader = new BufferedReader(isr);
            String line = bufferedReader.readLine();
            return line;

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    private ArrayList<String> readCsvFile() {
        ArrayList<String> blockedNumbers = new ArrayList<>();
        try {
            FileInputStream fis = openFileInput("csvFile.csv");
            InputStreamReader isr = new InputStreamReader(fis, StandardCharsets.UTF_8);
            BufferedReader bufferedReader = new BufferedReader(isr);
            String line = bufferedReader.readLine();

            while (line != null) {
                blockedNumbers.add(line);
                line = bufferedReader.readLine();

            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();

        } catch (IOException e) {
            e.printStackTrace();

        }
        return blockedNumbers;
    }


}