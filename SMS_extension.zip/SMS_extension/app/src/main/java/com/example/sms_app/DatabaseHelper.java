package com.example.sms_app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;


public class DatabaseHelper extends SQLiteOpenHelper {

    private static final int DB_VERSION = 1;
    private static final String DB_NAME = "sms.db";
    public static final String TABLE_NAME = "users";
    private static final String COLUMN_ID = "id";
    public static final String COLUMN_NAME = "name";
    public static final String COLUMN_CONTENT = "content";
    private static final String BLOCK_CONTACT_TABLE = "blockContact";
    private static final String COLUMN_ID_BLOCK_CONTACT_TABLE = "id";
    private static final String COLUMN_BLOCK_CONTACT_NUMBER = "blockNo";

    private static String CREATE_TABLE;

    private static String CREATE_TABLE_BLOCKED_CONTACT;

    private static DatabaseHelper databaseHelper;

    private DatabaseHelper(Context context) {

         super(context,DB_NAME, null, DB_VERSION);

    }

    public static synchronized DatabaseHelper getInstance(Context context) {

        if (databaseHelper == null) {
            databaseHelper = new DatabaseHelper(context);
        }
        return databaseHelper;
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_NAME + " TEXT,"
                + COLUMN_CONTENT + " TEXT" + ")";
        db.execSQL(CREATE_TABLE);

        CREATE_TABLE_BLOCKED_CONTACT= "CREATE TABLE " + BLOCK_CONTACT_TABLE + "("
                + COLUMN_ID_BLOCK_CONTACT_TABLE + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_BLOCK_CONTACT_NUMBER + " TEXT" + ")";
        db.execSQL(CREATE_TABLE_BLOCKED_CONTACT);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);

        onCreate(db);

    }

    public Long insertBlockContact(Context context, String mContacts){
        SQLiteDatabase db =DatabaseHelper.getInstance(context).getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_BLOCK_CONTACT_NUMBER, mContacts);
        Long newRowId = db.insert(BLOCK_CONTACT_TABLE, null, values);
        db.close();
        return newRowId;


    }
    public static boolean checkBlockedContacts(Context context, String mContacts){
        SQLiteDatabase db =new DatabaseHelper(context).getReadableDatabase();
        String whereClause = COLUMN_BLOCK_CONTACT_NUMBER + " = ?";
        Cursor cursor = db.query(
                BLOCK_CONTACT_TABLE,
                null,
                whereClause,
                new String[]{mContacts},
                null,
                null,
                null);
        if ( cursor.getCount() == 0) {
            return false;
        } else {
            return true;
        }
    }


}
