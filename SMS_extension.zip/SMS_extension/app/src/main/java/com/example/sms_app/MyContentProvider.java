package com.example.sms_app;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;


import static com.example.sms_app.DatabaseHelper.TABLE_NAME;

public class MyContentProvider extends ContentProvider {


    private static UriMatcher uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
    private SQLiteDatabase sqLiteDatabase;

    {
        uriMatcher.addURI("com.example.sms_app", "users", 1);
    }


    @Override
    public boolean onCreate() {
        DatabaseHelper databaseHelper = DatabaseHelper.getInstance(getContext());
        SQLiteDatabase db = databaseHelper.getWritableDatabase();
        if (db != null) {
            return true;
        }
        return false;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection,
                        String[] selectionArgs, String sortOrder) {

        DatabaseHelper databaseHelper = DatabaseHelper.getInstance(getContext());
        SQLiteDatabase db = databaseHelper.getReadableDatabase();
        switch (uriMatcher.match(uri)) {
            case 1:
                return db.query(TABLE_NAME, projection, selection, selectionArgs, null, null, sortOrder);
            default:
                throw new IllegalArgumentException("unsupported uri : " + uri);
        }

    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {

        DatabaseHelper databaseHelper = DatabaseHelper.getInstance(getContext());
        SQLiteDatabase db = databaseHelper.getWritableDatabase();
        long id;
        switch (uriMatcher.match(uri)) {
            case 1:
                id = db.insert(TABLE_NAME, null, values);
                break;
            default:
                throw new IllegalArgumentException("unsupported uri : " + uri);
        }
        if (id > 0) {
            Uri notifyUri = ContentUris.withAppendedId(uri, id);
            getContext().getContentResolver().notifyChange(notifyUri, null);
            return notifyUri;
        }
        return null;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        int count = 0;
        DatabaseHelper databaseHelper = DatabaseHelper.getInstance(getContext());
        SQLiteDatabase db = databaseHelper.getWritableDatabase();
        switch (uriMatcher.match(uri)) {
            case 1:
                count = db.delete(TABLE_NAME, selection, selectionArgs);
                break;
            default:
                throw new IllegalArgumentException("unsupported uri : " + uri);
        }


        getContext().getContentResolver().notifyChange(uri, null);
        return count;

    }

    @Override
    public int update(Uri uri, ContentValues values, String selection,
                      String[] selectionArgs) {

        int count;
        DatabaseHelper databaseHelper = DatabaseHelper.getInstance(getContext());
        SQLiteDatabase db = databaseHelper.getWritableDatabase();
        switch (uriMatcher.match(uri)) {
            case 1:
                count = db.update(TABLE_NAME, values, selection, selectionArgs);
                break;
            default:
                throw new IllegalArgumentException("unsupported uri : " + uri);
        }


        getContext().getContentResolver().notifyChange(uri, null);
        return count;
    }



    @Override
    public String getType(Uri uri) {
        switch (uriMatcher.match(uri)) {
            case 1:
                return "com.example.sms_app/users";
            default:
                throw new IllegalArgumentException("unsupported uri : " + uri);
        }
    }


}
