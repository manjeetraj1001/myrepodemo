package com.android.manjeet.inshorttask.model;

import com.google.gson.annotations.SerializedName;

public class ListResults {

    @SerializedName(EndPoint.ID)
    private String id;
    @SerializedName(EndPoint.POSTER_PATH)
    private String posterPath;
    @SerializedName(EndPoint.TITLE)
    private String title;

    public ListResults(String id, String posterPath) {
        this.id = id;
        this.posterPath = posterPath;
    }

    public String getId() {
        return id;
    }

    public String getPosterPath() {
        return posterPath;
    }

    public String getTitle(){return title;}
}
