package com.android.manjeet.inshorttask.fragments;

import android.annotation.SuppressLint;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.os.Parcelable;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.manjeet.inshorttask.R;
import com.android.manjeet.inshorttask.adapter.ListAdapter;
import com.android.manjeet.inshorttask.model.ListResults;
import com.android.manjeet.inshorttask.model.ShowList;
import com.android.manjeet.inshorttask.viewModel.MovieListVM;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

import static java.util.ResourceBundle.getBundle;

public class MoviesFragment extends Fragment implements SharedPreferences.OnSharedPreferenceChangeListener {
    //  XML Views
    @BindView(R.id.fragmentRvAtMv) RecyclerView recyclerView;
    @BindView(R.id.fragmentPbAtMv) ProgressBar progressBar;
    @BindView(R.id.errorLayoutAtMv) RelativeLayout errorLayout;
    @BindView(R.id.showPageNo) TextView pageText;
    @BindView(R.id.nextAtMv) Button next;
    @BindView(R.id.previousAtMv) Button previous;
    private ImageView menu;

    //  Api Key
    @BindString(R.string.apiKey) String API_KEY;

    //  Sort Features
    @BindString(R.string.trendingQ) String TRENDING;
    @BindString(R.string.nowPlayingQ) String NOW_PLAYING;

    // Temporary Variable To Store Sort Pref
    @BindString(R.string.nowPlayingQ) String MOVIE_SORT_BY;

    //  Key To Restore From Shared Pref
    @BindString(R.string.movieSortPref) String movieSortKey;
    @BindString(R.string.currentPage) String currentPageKey;
    @BindString(R.string.recyclerViewState) String recyclerStateKey;

    //  Temporary Variables
    private int NO_OF_IMAGE = 2;
    private int currentPage = 1;
    private int previousPage = 1;
    private int totalPage = 1;
    private List<ListResults> listResults;
    private ShowList tempShowList = new ShowList();
    private Toast toast;
    private boolean flag = true;
    private Parcelable parcelable;
    private boolean searchFlag = false;
    private String searchedWord = "";

    public MoviesFragment() {

    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_movies, container, false);
        ButterKnife.bind(this,view);
        loadPreferences();

        if(savedInstanceState != null){
            if(savedInstanceState.containsKey(movieSortKey)){
                MOVIE_SORT_BY = savedInstanceState.getString(movieSortKey);
            }
            if(savedInstanceState.containsKey(currentPageKey)){
                currentPage = savedInstanceState.getInt(currentPageKey);
                previousPage = currentPage;
            }
            if(savedInstanceState.containsKey(recyclerStateKey)){
                 parcelable = ((Bundle) savedInstanceState).getParcelable(recyclerStateKey);
            }
            flag = false;
        }

        menu = getActivity().findViewById(R.id.menuBtn);
        registerForContextMenu(menu);

        return view;
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString(movieSortKey,MOVIE_SORT_BY);
        outState.putInt(currentPageKey, currentPage);
        outState.putParcelable(recyclerStateKey,recyclerView.getLayoutManager().onSaveInstanceState());
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        checkOrientation();
        loadMovies();

        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(toast != null){
                    toast.cancel();
                }
                toast = Toast.makeText(getActivity(),getResources().getString(R.string.pressLong),Toast.LENGTH_SHORT);
                toast.show();
            }
        });
    }

    private void loadFilteredMovies(final String s){
        Log.d("manjeet","loadFilteredMovies" + s );
        searchedWord = s;
        searchFlag = true;
        if(!networkStatus()&&flag){
            showError();
            return;
        }
        if(!searchedWord.equals("")) {
            MovieListVM moviesViewModel = ViewModelProviders.of(this).get(MovieListVM.class);
            moviesViewModel.getSearchedMoviesList(API_KEY, searchedWord, currentPage, previousPage).observe(this, new Observer<ShowList>() {
                @Override
                public void onChanged(@Nullable ShowList showList) {
                    for (int i = 0; i < showList.getResults().size(); i++) {
                        Log.d("manjeet", showList.getResults().get(i).getTitle());
                    }
                    if (tempShowList.equals(showList)) {
                        return;
                    } else {
                        tempShowList = showList;
                        setMovieList(showList);
                    }
                }
            });
        }
        else{
            loadMovies();
        }
    }

    public void searchMovie(String query){
        loadFilteredMovies(query);
    }

    private void checkOrientation(){
        int configuration = this.getResources().getConfiguration().orientation;
        if(configuration == Configuration.ORIENTATION_PORTRAIT){
            NO_OF_IMAGE = 2;
        }else{
            NO_OF_IMAGE = 4;
        }
    }

    private void loadPreferences(){
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
        MOVIE_SORT_BY = sharedPreferences.getString(movieSortKey,NOW_PLAYING);
        sharedPreferences.registerOnSharedPreferenceChangeListener(this);
    }

    private void loadMovies(){
        if(!networkStatus()&&flag){
            showError();
            return;
        }
        progressBar.setVisibility(View.VISIBLE);
        MovieListVM moviesViewModel = ViewModelProviders.of(this).get(MovieListVM.class);
        if(MOVIE_SORT_BY.equals(NOW_PLAYING)) {
            moviesViewModel.getNowPlayingMoviesList(API_KEY, currentPage, previousPage).observe(this, new Observer<ShowList>() {
               @Override
               public void onChanged(@Nullable ShowList showList) {
                   if (tempShowList.equals(showList)) {
                       return;
                   } else {
                       tempShowList = showList;
                       setMovieList(showList);
                   }
               }
           });
       }
       else{
            moviesViewModel.getTrendingMoviesList(API_KEY, currentPage,previousPage).observe(this, new Observer<ShowList>() {
               @Override
               public void onChanged(@Nullable ShowList showList) {

                   if(tempShowList.equals(showList)){
                       return;
                   }else{
                       tempShowList = showList;
                       setMovieList(showList);
                   }
               }
           });
       }
    }

    private void setFilterMovie(List<ListResults> arrayList) {

        progressBar.setVisibility(View.GONE);
        errorLayout.setVisibility(View.GONE);
        recyclerView.setVisibility(View.VISIBLE);

        previousPage = currentPage;

        doPagination();

        int resId = R.anim.recycler_animation;
        LayoutAnimationController animation = AnimationUtils.loadLayoutAnimation(getActivity(), resId);
        recyclerView.setLayoutAnimation(animation);

        ListAdapter movieListAdapter = new ListAdapter(arrayList,getActivity(),"Movie");
        //recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), NO_OF_IMAGE));
        recyclerView.setAdapter(movieListAdapter);
        if(parcelable != null){
            recyclerView.getLayoutManager().onRestoreInstanceState(parcelable);
        }

    }

    private void setMovieList(ShowList showList){
        if(showList == null || showList.getResults().size() == 0){
            showError();
            return;
        }
        progressBar.setVisibility(View.GONE);
        errorLayout.setVisibility(View.GONE);
        recyclerView.setVisibility(View.VISIBLE);

        totalPage = showList.getTotalPages();
        listResults = showList.getResults();
        previousPage = currentPage;

        doPagination();

        int resId = R.anim.recycler_animation;
        LayoutAnimationController animation = AnimationUtils.loadLayoutAnimation(getActivity(), resId);
        recyclerView.setLayoutAnimation(animation);

        ListAdapter movieListAdapter = new ListAdapter(listResults,getActivity(),"Movie");
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), NO_OF_IMAGE));
        recyclerView.setAdapter(movieListAdapter);
        if(parcelable != null){
            recyclerView.getLayoutManager().onRestoreInstanceState(parcelable);
        }
    }

    private void showError(){
        progressBar.setVisibility(View.GONE);
        errorLayout.setVisibility(View.VISIBLE);
        pageText.setVisibility(View.INVISIBLE);
        next.setVisibility(View.INVISIBLE);
        previous.setVisibility(View.INVISIBLE);
        recyclerView.setVisibility(View.INVISIBLE);
    }

    private boolean networkStatus(){
        if (getActivity()!=null){
            ConnectivityManager connectivityManager = (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
            return (connectivityManager.getActiveNetworkInfo() != null && connectivityManager.getActiveNetworkInfo().isAvailable() && connectivityManager.getActiveNetworkInfo().isConnected());
        }
       return true;
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String s) {
        if(s.equals(movieSortKey)){
            MOVIE_SORT_BY = sharedPreferences.getString(movieSortKey,NOW_PLAYING);
            loadMovies();
        }
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        MenuInflater menuInflater = getActivity().getMenuInflater();
        menuInflater.inflate(R.menu.movie_sort_by,menu);

        MenuItem trending = menu.findItem(R.id.trendingMv);
        MenuItem nowPlaying = menu.findItem(R.id.nowPlayMv);

        if(MOVIE_SORT_BY.equalsIgnoreCase(NOW_PLAYING)){
            nowPlaying.setChecked(true);
        }
        else{
            trending.setChecked(true);
        }
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.trendingMv :
                item.setChecked(true);
                MOVIE_SORT_BY = TRENDING;
                loadMovies();
                return true;
            case R.id.nowPlayMv :
                item.setChecked(true);
                MOVIE_SORT_BY = NOW_PLAYING;
                loadMovies();
                return true;
        }

        return super.onContextItemSelected(item);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        PreferenceManager.getDefaultSharedPreferences(getContext()).unregisterOnSharedPreferenceChangeListener(this);
    }

    @OnClick(R.id.retryAtMv)
    void refresh(){
        loadMovies();
    }
    @OnClick(R.id.nextAtMv)
    void loadNext(){
        currentPage++;
        flag = true;
        if(searchFlag == true){
            loadFilteredMovies(searchedWord);
        }else {
            loadMovies();
        }
    }
    @OnClick(R.id.previousAtMv)
    void loadPrv(){
        currentPage--;
        flag = true;
        if(searchFlag == true){
            loadFilteredMovies(searchedWord);
        }else {
            loadMovies();
        }
    }

    private void doPagination(){
        if(currentPage == 1){
            previous.setVisibility(View.GONE);
        }else if(currentPage >1){
            previous.setVisibility(View.VISIBLE);
        }

        if(currentPage >= totalPage){
            next.setVisibility(View.GONE);
        }else if(currentPage < totalPage){
            next.setVisibility(View.VISIBLE);
        }
        pageText.setVisibility(View.VISIBLE);
        pageText.setText("Page "+ currentPage +" of "+ totalPage);
    }

}
