package com.android.manjeet.inshorttask.viewModel;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import com.android.manjeet.inshorttask.model.MovieDetail;
import com.android.manjeet.inshorttask.network.ApiRepository;

public class MovieDetailApiVM extends ViewModel{

    private MutableLiveData<MovieDetail> movieDetailFromApi;
    private ApiRepository apiRepository = new ApiRepository();

    public LiveData<MovieDetail> getMovieDetailFromApi(String movieId,String ApiKey,String AppendQuery){
        if(movieDetailFromApi == null){
            movieDetailFromApi = apiRepository.loadMovieDetailFromApi(movieId,ApiKey,AppendQuery);
        }
        return movieDetailFromApi;
    }

}

