package com.android.manjeet.inshorttask.viewModel;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;
import android.content.Intent;
import android.util.Log;

import com.android.manjeet.inshorttask.R;
import com.android.manjeet.inshorttask.model.ShowList;
import com.android.manjeet.inshorttask.network.ApiRepository;

public class MovieListVM extends ViewModel {

    private MutableLiveData<ShowList> trendingMovieList;
    private MutableLiveData<ShowList> nowPlayingMovieList;
    private MutableLiveData<ShowList> searchedMovieList;

    private ApiRepository apiRepository = new ApiRepository();

    public LiveData<ShowList> getNowPlayingMoviesList(String API_KEY,int currentPage,int previousPage) {
        if (nowPlayingMovieList == null || currentPage != previousPage) {
            nowPlayingMovieList = apiRepository.loadNowPlayingMovies(API_KEY,currentPage);
        }
        return nowPlayingMovieList;
    }
    public LiveData<ShowList> getTrendingMoviesList(String API_KEY,int currentPage,int previousPage) {
        if (trendingMovieList == null || currentPage != previousPage) {
            trendingMovieList = apiRepository.loadTrendingMovies(API_KEY,currentPage);
        }
        return trendingMovieList;
    }

    public LiveData<ShowList> getSearchedMoviesList(String API_KEY,String query,int currentPage,int previousPage) {
            searchedMovieList = apiRepository.loadSearchedMovies(API_KEY,query,currentPage);
        return searchedMovieList;
    }

}
