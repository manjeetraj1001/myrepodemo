package com.android.manjeet.inshorttask.viewModel;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.ViewModel;

import com.android.manjeet.inshorttask.db.ShowDatabase;
import com.android.manjeet.inshorttask.model.MovieDetail;

public class MovieDetailDbVM extends ViewModel {

    private LiveData<MovieDetail> movieDetail;

    public MovieDetailDbVM(ShowDatabase showDatabase, String movieId) {
        movieDetail = showDatabase.showDao().getMovieDetail(movieId);
    }

    public LiveData<MovieDetail> getMovieDetail() {
        return movieDetail;
    }
}
