package com.android.manjeet.inshorttask.db;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;

import com.android.manjeet.inshorttask.model.MovieCastsResult;
import com.android.manjeet.inshorttask.model.MovieDetail;
import com.android.manjeet.inshorttask.model.ProductionCompany;
import com.android.manjeet.inshorttask.model.VideosResults;

@Database(entities = {MovieDetail.class, MovieCastsResult.class,ProductionCompany.class, VideosResults.class},version = 2,exportSchema = false)
public abstract class ShowDatabase extends RoomDatabase{

    private static final Object LOCK = new Object();
    private static final String DATABASE_NAME = "SHOW_DATABASE";
    private static ShowDatabase showDatabase;

    public static ShowDatabase getShowDatabase(Context context){
        if(showDatabase == null){
            synchronized (LOCK){
                showDatabase = Room.databaseBuilder(context.getApplicationContext(),
                        ShowDatabase.class,
                        ShowDatabase.DATABASE_NAME)
                        .build();
            }
        }
        return showDatabase;
    }

    public abstract ShowDao showDao();
}
