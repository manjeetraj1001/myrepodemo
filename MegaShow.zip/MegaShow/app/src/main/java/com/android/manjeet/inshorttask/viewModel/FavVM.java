package com.android.manjeet.inshorttask.viewModel;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.support.annotation.NonNull;

import com.android.manjeet.inshorttask.db.ShowDatabase;
import com.android.manjeet.inshorttask.model.MovieDetail;

import java.util.List;

public class FavVM extends AndroidViewModel {

    private final LiveData<List<MovieDetail>> movieDetailList;

    public FavVM(@NonNull Application application) {
        super(application);
        ShowDatabase showDatabase = ShowDatabase.getShowDatabase(this.getApplication());
        movieDetailList = showDatabase.showDao().getListOfMv();

    }
    public LiveData<List<MovieDetail>> getMovieDetailList() {
        return movieDetailList;
    }
}
