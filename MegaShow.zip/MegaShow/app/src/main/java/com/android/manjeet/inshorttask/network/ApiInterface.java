package com.android.manjeet.inshorttask.network;

import com.android.manjeet.inshorttask.model.EndPoint;
import com.android.manjeet.inshorttask.model.ShowList;
import com.android.manjeet.inshorttask.model.MovieDetail;
import com.android.manjeet.inshorttask.model.PersonProfile;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ApiInterface {

    @GET(EndPoint.NOW_PLAYING_URL)
    Call<ShowList> getNowPlayingMovies(@Query(EndPoint.API_QUERY) String apiKey, @Query(EndPoint.PAGE_QUERY) int page);

    @GET(EndPoint.TENDING_URL)
    Call<ShowList> getTrendingMovies(@Query(EndPoint.API_QUERY) String apiKey, @Query(EndPoint.PAGE_QUERY) int page);

    @GET(EndPoint.MOVIE_DETAIL_URl)
    Call<MovieDetail> getMovieDetail(@Path(EndPoint.ID_QUERY) String id, @Query(EndPoint.API_QUERY) String apiKey, @Query(EndPoint.APPEND_TO_RESPONSE) String append);

    @GET(EndPoint.SEARCHED_URL)
    Call<ShowList> getSearchedMovies(@Query(EndPoint.API_QUERY) String apiKey, @Query(EndPoint.SEARCHED_QUERY) String query, @Query(EndPoint.PAGE_QUERY) int page);

}
