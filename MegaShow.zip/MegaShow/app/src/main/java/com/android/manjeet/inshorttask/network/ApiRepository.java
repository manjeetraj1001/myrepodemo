package com.android.manjeet.inshorttask.network;

import android.arch.lifecycle.MutableLiveData;
import android.support.annotation.NonNull;
import android.util.Log;

import com.android.manjeet.inshorttask.model.MovieDetail;
import com.android.manjeet.inshorttask.model.PersonProfile;
import com.android.manjeet.inshorttask.model.ShowList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ApiRepository {

    private ApiInterface apiInterface = BuildUrl.getRetrofit().create(ApiInterface.class);

    public MutableLiveData<ShowList> loadNowPlayingMovies(String API_KEY,int CURRENT_PAGE){
        final MutableLiveData<ShowList> nowPlayingMovieList = new MutableLiveData<>();
        apiInterface.getNowPlayingMovies(API_KEY,CURRENT_PAGE).enqueue(new Callback<ShowList>() {
            @Override
            public void onResponse(@NonNull Call<ShowList> call, @NonNull Response<ShowList> response) {
                nowPlayingMovieList.setValue(response.body());
            }

            @Override
            public void onFailure(@NonNull Call<ShowList> call, @NonNull Throwable t) {

            }
        });
        return nowPlayingMovieList;
    }

    public MutableLiveData<ShowList> loadSearchedMovies(String API_KEY,String QUERY, int CURRENT_PAGE){
        final MutableLiveData<ShowList> searchedMovieList = new MutableLiveData<>();
        apiInterface.getSearchedMovies(API_KEY,QUERY,CURRENT_PAGE).enqueue(new Callback<ShowList>() {
            @Override
            public void onResponse(@NonNull Call<ShowList> call, @NonNull Response<ShowList> response) {
                searchedMovieList.setValue(response.body());
            }

            @Override
            public void onFailure(@NonNull Call<ShowList> call, @NonNull Throwable t) {
            }
        });
        return searchedMovieList;
    }

    public MutableLiveData<ShowList> loadTrendingMovies(String API_KEY,int CURRENT_PAGE){
        final MutableLiveData<ShowList> loadTrendingMoviesList = new MutableLiveData<>();
        apiInterface.getTrendingMovies(API_KEY,CURRENT_PAGE).enqueue(new Callback<ShowList>() {
            @Override
            public void onResponse(@NonNull Call<ShowList> call, @NonNull Response<ShowList> response) {
                loadTrendingMoviesList.setValue(response.body());
            }

            @Override
            public void onFailure(@NonNull Call<ShowList> call, @NonNull Throwable t) {

            }
        });
        return loadTrendingMoviesList;
    }



    public MutableLiveData<MovieDetail> loadMovieDetailFromApi(String movieId,String ApiKey,String AppendQuery){
        final MutableLiveData<MovieDetail> movieDetailFromApi = new MutableLiveData<>();
        apiInterface.getMovieDetail(movieId,ApiKey,AppendQuery).enqueue(new Callback<MovieDetail>() {
            @Override
            public void onResponse(@NonNull Call<MovieDetail> call, @NonNull Response<MovieDetail> response) {
                movieDetailFromApi.setValue(response.body());
            }

            @Override
            public void onFailure(@NonNull Call<MovieDetail> call, @NonNull Throwable t) {

            }
        });
        return movieDetailFromApi;
    }



}
