package com.example.smsviewer;


import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {

    private String URI = "content://com.example.sms_app/users";

    private TextView textViewCount;
    private TextView textViewContent;

    private Button button;

    String TAG="ERROR";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        textViewContent = findViewById(R.id.textview_content);
        textViewCount = findViewById(R.id.textview_count);
        button = findViewById(R.id.button);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setAllContent();
            }
        });

        setCount();
    }





    private void setAllContent() {

        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(Uri.parse(URI),
                    null,
                    null,
                    null,
                    null,
                    null);


        } catch (NullPointerException n) {
            Log.i(TAG, "NullPointerException");
        } finally {
            StringBuilder stringBuilder = new StringBuilder("");
            if (cursor != null) {

                while (cursor.moveToNext()) {
                    stringBuilder.append(cursor.getInt(0) + ". " + cursor.getLong(1) + "\n "
                            + "   " + cursor.getString(2) + "\n\n");
                }
                textViewContent.setText(stringBuilder.toString());
                Log.i(TAG, stringBuilder.toString());
            }


        }


    }

    private void setCount() {
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(Uri.parse(URI),
                    null,
                    null,
                    null,
                    null,
                    null);
        } finally {
            if (cursor != null) {
                textViewCount.setText("Total Row Count: " + cursor.getCount());
                cursor.close();
            }

        }


    }


}