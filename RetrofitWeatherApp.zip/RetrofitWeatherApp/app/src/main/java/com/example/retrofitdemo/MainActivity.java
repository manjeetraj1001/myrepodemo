package com.example.retrofitdemo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.material.navigation.NavigationView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private DrawerLayout drawerLayout;

    private TextView country_name;

    private TextView textView_min;
    private TextView textView_max;
    private TextView textView_actual;
    private TextView textView_humidity;
    private TextView textView_predictability;

    private TextView weatherStateName_textView_one;
    private TextView weatherStateName_textView_two;
    private TextView weatherStateName_textView_three;
    private TextView weatherStateName_textView_four;
    private TextView weatherStateName_textView_five;

    private ImageView weatherStateAbbr_today_image;
    private ImageView weatherStateAbbr_image_one;
    private ImageView weatherStateAbbr_image_two;
    private ImageView weatherStateAbbr_image_three;
    private ImageView weatherStateAbbr_image_four;
    private ImageView weatherStateAbbr_image_five;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        country_name = findViewById(R.id.header);

        textView_min = findViewById(R.id.min_temp);

        textView_max = findViewById(R.id.max_temp);

        textView_actual = findViewById(R.id.actual_temp);

        textView_humidity = findViewById(R.id.humidity);

        textView_predictability = findViewById(R.id.predictability);

        weatherStateName_textView_one = findViewById(R.id.textview_one);

        weatherStateName_textView_two = findViewById(R.id.textview_two);

        weatherStateName_textView_three = findViewById(R.id.textview_three);

        weatherStateName_textView_four = findViewById(R.id.textview_four);

        weatherStateName_textView_five = findViewById(R.id.textview_five);


        weatherStateAbbr_today_image = findViewById(R.id.today_imageView);

        weatherStateAbbr_image_one = findViewById(R.id.imageView_one);

        weatherStateAbbr_image_two = findViewById(R.id.imageView_two);

        weatherStateAbbr_image_three = findViewById(R.id.imageView_three);

        weatherStateAbbr_image_four = findViewById(R.id.imageView_four);

        weatherStateAbbr_image_five = findViewById(R.id.imageView_five);

        getData("44418/");


        //work as actionbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //to create hamburger icon
        drawerLayout = findViewById(R.id.drawer_layout);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar,
                R.string.open_navigation_drawer, R.string.close_navigation_drawer);

        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        //to select items from navigationView
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        String LONDON = "44418/";
        String INDIA = "2427032/";
        String DUBAI = "1940345/";
        String SAN_FRAN = "2487956/";
        String MOSCOW = "2122265/";
        String MONTREAL = "3534/";


        country_name.setText(menuItem.getTitle());

        switch (menuItem.getItemId()) {
            case R.id.nav_dubai:
                getData(DUBAI);
                break;
            case R.id.nav_india:
                getData(INDIA);
                break;
            case R.id.nav_london:
                getData(LONDON);
                break;
            case R.id.nav_montreal:
                getData(MONTREAL);
                break;
            case R.id.nav_moscow:
                getData(MOSCOW);
                break;
            case R.id.nav_san_fran:
                getData(SAN_FRAN);
                break;

            default:
                Toast.makeText(this, "ERROR", Toast.LENGTH_SHORT).show();

        }

        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    public void getData(String mCountry){
        ApiServices services = RetrofitClient.getInstance().create(ApiServices.class);
        Call<ModelClass> call = services.get(mCountry);
        call.enqueue(new Callback<ModelClass>() {
            @Override
            public void onResponse(Call<ModelClass> call, Response<ModelClass> response) {
                if (!response.isSuccessful()) {
                    country_name.setText("Code: " + response.code());
                    return;
                }
                ModelClass posts = response.body();
                textView_min.setText(String.valueOf(posts.getConsolidatedWeather().get(0).getMinTemp()) );
                textView_max.setText(String.valueOf(posts.getConsolidatedWeather().get(0).getMaxTemp()) );
                textView_actual.setText(String.valueOf(posts.getConsolidatedWeather().get(0).getTheTemp()) );
                textView_humidity.setText(String.valueOf(posts.getConsolidatedWeather().get(0).getHumidity()) );
                textView_predictability.setText(String.valueOf(posts.getConsolidatedWeather().get(0).getPredictability()) );

                weatherStateName_textView_one.setText(String.valueOf(posts.getConsolidatedWeather().get(0).getWeatherStateName()));
                weatherStateName_textView_two.setText(String.valueOf(posts.getConsolidatedWeather().get(1).getWeatherStateName()));
                weatherStateName_textView_three.setText(String.valueOf(posts.getConsolidatedWeather().get(2).getWeatherStateName()));
                weatherStateName_textView_four.setText(String.valueOf(posts.getConsolidatedWeather().get(3).getWeatherStateName()));
                weatherStateName_textView_five.setText(String.valueOf(posts.getConsolidatedWeather().get(4).getWeatherStateName()));

                weatherStateAbbr_today_image.setImageResource(getImage(posts.getConsolidatedWeather().get(0).getWeatherStateAbbr()));
                weatherStateAbbr_image_one.setImageResource(getImage(posts.getConsolidatedWeather().get(0).getWeatherStateAbbr()));
                weatherStateAbbr_image_two.setImageResource(getImage(posts.getConsolidatedWeather().get(1).getWeatherStateAbbr()));
                weatherStateAbbr_image_three.setImageResource(getImage(posts.getConsolidatedWeather().get(2).getWeatherStateAbbr()));
                weatherStateAbbr_image_four.setImageResource(getImage(posts.getConsolidatedWeather().get(3).getWeatherStateAbbr()));
                weatherStateAbbr_image_five.setImageResource(getImage(posts.getConsolidatedWeather().get(4).getWeatherStateAbbr()));



            }

            @Override
            public void onFailure(Call<ModelClass> call, Throwable t) {
                country_name.setText(t.getMessage());
            }
        });

    }

    private int getImage(String weather_state_abbr) {
        switch (weather_state_abbr) {
            case "c":
                return R.drawable.c;
            case "h":
                return R.drawable.h;

            case "hc":
                return R.drawable.hc;

            case "lc":
                return R.drawable.lc;

            case "lr":
                return R.drawable.lr;

            case "s":
                return R.drawable.s;

            case "hr":
                return R.drawable.hr;

            case "sl":
                return R.drawable.sl;

            case "sn":
                return R.drawable.sn;

            case "t":
                return R.drawable.t;


            default:
                return 0;
        }
    }
}