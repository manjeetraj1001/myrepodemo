package com.example.retrofitdemo;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;


public interface ApiServices {

    @GET("api/location/{id}")
    Call<ModelClass> get(@Path("id") String id);




}
